import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookCRUDApp {
    private List<Book> books = new ArrayList<>();
    private int nextId = 1;

    public static void main(String[] args) {
        BookCRUDApp app = new BookCRUDApp();
        app.run();
    }

    private void run() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("CRUD Application - Choose an option:");
            System.out.println("1. Add a book");
            System.out.println("2. View all books");
            System.out.println("3. Update a book");
            System.out.println("4. Delete a book");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addBook();
                    break;
                case 2:
                    viewAllBooks();
                    break;
                case 3:
                    updateBook();
                    break;
                case 4:
                    deleteBook();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 5);
    }

    private void addBook() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter title: ");
        String title = scanner.nextLine();

        System.out.print("Enter author: ");
        String author = scanner.nextLine();

        Book book = new Book(nextId, title, author);
        books.add(book);
        nextId++;

        System.out.println("Book added successfully!");
    }

    private void viewAllBooks() {
        if (books.isEmpty()) {
            System.out.println("No books found.");
        } else {
            System.out.println("List of all books:");
            for (Book book : books) {
                System.out.println(book);
            }
        }
    }

    private void updateBook() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the book ID to update: ");
        int id = scanner.nextInt();

        Book bookToUpdate = findBookById(id);
        if (bookToUpdate == null) {
            System.out.println("Book not found with ID: " + id);
        } else {
            System.out.print("Enter new title: ");
            scanner.nextLine(); // Consume the newline character left by nextInt()
            String newTitle = scanner.nextLine();

            System.out.print("Enter new author: ");
            String newAuthor = scanner.nextLine();

            bookToUpdate.setTitle(newTitle);
            bookToUpdate.setAuthor(newAuthor);

            System.out.println("Book updated successfully!");
        }
    }

    private void deleteBook() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the book ID to delete: ");
        int id = scanner.nextInt();

        Book bookToDelete = findBookById(id);
        if (bookToDelete == null) {
            System.out.println("Book not found with ID: " + id);
        } else {
            books.remove(bookToDelete);
            System.out.println("Book deleted successfully!");
        }
    }

    private Book findBookById(int id) {
        for (Book book : books) {
            if (book.getId() == id) {
                return book;
            }
        }
        return null;
    }
}
